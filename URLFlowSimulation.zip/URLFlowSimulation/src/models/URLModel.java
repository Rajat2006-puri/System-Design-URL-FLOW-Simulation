package models;

public class URLModel {

    private String protocol;
    private String hostname;
    private String path;
    private int port;

    public URLModel(String url) {
        parse(url);
    }

    private void parse(String url) {

        if (url.startsWith("https://")) {
            protocol = "https";
            url = url.substring(8);
            port = 443;
        } else {
            protocol = "http";
            url = url.substring(7);
            port = 80;
        }

        String[] parts = url.split("/", 2);
        hostname = parts[0];
        path = parts.length > 1 ? "/" + parts[1] : "/";
    }

    public String getProtocol() { return protocol; }
    public String getHostname() { return hostname; }
    public String getPath() { return path; }
    public int getPort() { return port; }

    @Override
    public String toString() {
        return "Protocol=" + protocol +
               ", Host=" + hostname +
               ", Path=" + path +
               ", Port=" + port;
    }
}
