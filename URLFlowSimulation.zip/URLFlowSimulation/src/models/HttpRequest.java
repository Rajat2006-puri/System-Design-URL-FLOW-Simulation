package models;

import java.util.HashMap;
import java.util.Map;

public class HttpRequest {

    private String method;
    private String path;
    private boolean secure;
    private Map<String, String> headers = new HashMap<>();

    public void setMethod(String method) { this.method = method; }
    public void setPath(String path) { this.path = path; }
    public void setSecure(boolean secure) { this.secure = secure; }

    public String getMethod() { return method; }
    public String getPath() { return path; }
    public boolean isSecure() { return secure; }

    public void addHeader(String key, String value) {
        headers.put(key, value);
    }
}

