package models;

import java.util.HashMap;
import java.util.Map;

public class HttpResponse {

    private int statusCode;
    private String body;
    private Map<String, String> headers = new HashMap<>();

    public void setStatusCode(int code) { statusCode = code; }
    public void setBody(String body) { this.body = body; }

    public int getStatusCode() { return statusCode; }

    public void addHeader(String key, String value) {
        headers.put(key, value);
    }

    public void display() {
        System.out.println("Status: " + statusCode);
        System.out.println("Body: " + body);
    }
}

