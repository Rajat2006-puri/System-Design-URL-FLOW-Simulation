package components;

import models.HttpResponse;

public class BrowserSimulator {

    public void render(HttpResponse response) {

        System.out.println("[Browser] Rendering Page...");
        response.display();
    }
}
