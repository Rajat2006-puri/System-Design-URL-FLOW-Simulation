package components;

import java.util.HashMap;
import java.util.Map;

public class DNSResolver {

    private Map<String, String> records = new HashMap<>();

    public DNSResolver() {
        records.put("www.example.com", "93.184.216.34");
        records.put("localhost", "127.0.0.1");
    }

    public String resolve(String host) {
        System.out.println("[DNS] Resolving " + host);
        return records.getOrDefault(host, null);
    }
}

