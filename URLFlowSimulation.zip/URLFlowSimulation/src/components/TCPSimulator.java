package components;

public class TCPSimulator {

    public void connect(String ip, int port, boolean secure) {

        System.out.println("[TCP] Connecting to " + ip + ":" + port);

        System.out.println("SYN →");
        System.out.println("← SYN-ACK");
        System.out.println("ACK →");

        if (secure) {
            System.out.println("[TLS] Handshake...");
        }

        System.out.println("Connection Established");
    }

    public void close() {
        System.out.println("Connection Closed\n");
    }
}
