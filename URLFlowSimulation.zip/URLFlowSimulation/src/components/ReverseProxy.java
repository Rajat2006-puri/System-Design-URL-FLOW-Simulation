package components;

import models.HttpRequest;

public class ReverseProxy {

    public HttpRequest forward(HttpRequest request) {

        if (request.isSecure()) {
            System.out.println("[Proxy] SSL Termination");
            request.setSecure(false);
        }

        System.out.println("[Proxy] Forwarding to backend server");
        return request;
    }
}
