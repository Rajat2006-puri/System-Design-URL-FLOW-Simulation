package components;

import models.HttpRequest;
import models.HttpResponse;

public class WebServer {

    public HttpResponse handle(HttpRequest request) {

        System.out.println("[WebServer] Handling " + request.getPath());

        HttpResponse response = new HttpResponse();

        if (request.getPath().equals("/about")) {
            response.setStatusCode(200);
            response.setBody("<h1>About Page</h1>");
        } else {
            response.setStatusCode(200);
            response.setBody("<h1>Home Page</h1>");
        }

        return response;
    }
}

