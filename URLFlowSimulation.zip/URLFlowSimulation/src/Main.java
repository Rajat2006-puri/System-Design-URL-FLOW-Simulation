import components.*;
import models.*;

public class Main {

    public static void main(String[] args) throws InterruptedException {

        System.out.println("=================================================");
        System.out.println("        URL TO WEBSITE FLOW SIMULATION");
        System.out.println("-------------------------------------------------");
        System.out.println(" Name : Tamanna Jha");
        System.out.println(" UID  : 23BCS13217");
        System.out.println("=================================================\n");

        Thread.sleep(800);

        String urlInput = "https://www.example.com/about";

        System.out.println("🌐 User enters URL in browser:");
        System.out.println("👉 " + urlInput + "\n");

        Thread.sleep(800);

        URLModel url = new URLModel(urlInput);
        System.out.println("🔎 [Browser] Parsing URL...");
        Thread.sleep(600);
        System.out.println("✔ Parsed → " + url + "\n");

        // DNS
        DNSResolver dns = new DNSResolver();
        System.out.println("📡 [Browser → DNS] Sending DNS Request...");
        Thread.sleep(800);
        String ip = dns.resolve(url.getHostname());
        System.out.println("✔ IP Address Received → " + ip + "\n");

        // TCP
        TCPSimulator tcp = new TCPSimulator();
        System.out.println("🔗 [Browser → Server] Establishing Connection...");
        Thread.sleep(800);
        tcp.connect(ip, url.getPort(),
                url.getProtocol().equals("https"));

        // HTTP Request
        System.out.println("\n📤 Sending HTTP Request...");
        HttpRequest request = new HttpRequest();
        request.setMethod("GET");
        request.setPath(url.getPath());
        request.setSecure(url.getProtocol().equals("https"));

        Thread.sleep(800);

        // Reverse Proxy
        ReverseProxy proxy = new ReverseProxy();
        request = proxy.forward(request);

        Thread.sleep(800);

        // Web Server
        WebServer server = new WebServer();
        HttpResponse response = server.handle(request);

        Thread.sleep(800);

        // Browser Rendering
        System.out.println("\n🖥 [Browser] Processing Response...");
        Thread.sleep(600);
        BrowserSimulator browser = new BrowserSimulator();
        browser.render(response);

        Thread.sleep(600);

        tcp.close();

        // Final Summary
        System.out.println("\n=================================================");
        System.out.println("               REQUEST SUMMARY");
        System.out.println("-------------------------------------------------");
        System.out.println(" Protocol  : " + url.getProtocol().toUpperCase());
        System.out.println(" Status    : " + response.getStatusCode());
        System.out.println(" Server IP : " + ip);
        System.out.println("=================================================");
        System.out.println("✅ Simulation Completed Successfully!");
    }
}
